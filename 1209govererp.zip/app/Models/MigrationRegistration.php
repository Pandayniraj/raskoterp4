<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MigrationRegistration extends Model
{
    /**
     * @var array
     */

    /**
     * @var array
     */
    protected $table='migration_registrations';

    protected $guarded = ['id'];
    
}
