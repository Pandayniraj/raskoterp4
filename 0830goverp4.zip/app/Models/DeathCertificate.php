<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DeathCertificate extends Model
{
    /**
     * @var array
     */

    /**
     * @var array
     */
    protected $table='death_certificates';

    protected $guarded = ['id'];
    
}
