<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MarriageRegistration extends Model
{
    /**
     * @var array
     */

    /**
     * @var array
     */
    protected $table='marriage_registrations';

    protected $guarded = ['id'];
    
}
